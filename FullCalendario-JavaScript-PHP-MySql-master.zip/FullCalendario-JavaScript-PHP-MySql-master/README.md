# FullCaledario-JavaScript-PHP
 The calendar is based on FullCalendar. It allows you to add Edit and Delete Events.
